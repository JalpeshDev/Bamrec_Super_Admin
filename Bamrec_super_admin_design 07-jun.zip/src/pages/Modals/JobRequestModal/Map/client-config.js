export const GoogleMapsAPI = 'AIzaSyALhyr5ADT5W_qw9in5R2kUJKyG5nCyXFU';
