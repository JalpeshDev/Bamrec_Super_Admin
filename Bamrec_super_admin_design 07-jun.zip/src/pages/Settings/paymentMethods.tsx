
import React, { useState } from 'react'
import AppLayout from '../../components/layout/layout';

const paymentMethods = ({ match }: any) => {  
  return (
     <div>
         Welcome to paymentMethod Screen
     </div>
   
  )
}
export default paymentMethods;
