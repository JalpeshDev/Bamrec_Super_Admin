import React, { useState } from 'react'
import AppLayout from '../../components/layout/layout';

const Notification = ({ match }: any) => {  
  return (

     <div>
         Welcome to Notification Screen
     </div>

  )
}
export default Notification;
