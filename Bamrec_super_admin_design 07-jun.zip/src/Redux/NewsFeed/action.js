const actions={
ADD_NEWSFEED_DATA:"ADD_NEWSFEED_DATA"
}


export default actions